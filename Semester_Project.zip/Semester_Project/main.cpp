#include <iostream>
#include <string>
#include <unordered_map>

using namespace std;

// Define a struct to hold user information
struct User {
    string username;
    string password;
    string email;
    float contact;
};

// Define a class to manage user registration, login and password reset
class UserManager {
private:
    unordered_map<string, User> users; // Map to store registered users

public:
    // Register a new user
    void registerUser() {
        User user;
        cout<<"\n------------------------------------------\n";
		cout<<" Kindly provide your registration details "<<endl;
		cout<<"------------------------------------------"<<endl;
        cout << "  Enter your username: ";
        cin >> user.username;
        cout<<"  Enter your contact:  ";
        cin>>user.contact;
		cout << "  Enter your password: ";
        cin >> user.password;
        cout<<"  Confirm password:    ";
		cin>>user.password;        
        cout << "  Enter your email:    ";
        cin >> user.email;
        users[user.username] = user;
        cout<<"\n------------------------------------------"<<endl;
        cout << "........Registration successful!.........." << endl;
        cout<<"------------------------------------------\n\n\n";
        
    }

    // Login an existing user
    void loginUser() {
        string username, password;
        cout<<"\n------------------------------------------\n";
		cout<<" Kindly enter your details "<<endl;
		cout<<"------------------------------------------"<<endl;
        cout << "Enter username: ";
        cin >> username;
        cout << "Enter password: ";
        cin >> password;
        if (users.count(username) == 0) {
            cout << "User not found!" << endl;
        } else if (users[username].password != password) {
            cout << "\n......Incorrect password, try again!......" << endl;
        } else {
            cout << "\n......Login successful!......" << endl;
        }
    }

    // Reset password for an existing user
    void resetPassword() {
        string username, email, newPassword;
        cout << "Enter username: ";
        cin >> username;
        cout << "Enter email: ";
        cin >> email;
        if (users.count(username) == 0) {
            cout << "User not found!" << endl;
        } else if (users[username].email != email) {
            cout << "\n......Incorrect email!......" << endl;
        } else {
            cout << "Enter new password: ";
            cin >> newPassword;
            users[username].password = newPassword;
            cout << "\n......Password reset successful!......" << endl;
        }
    }
};

int main() {
    UserManager userManager;
    int choice;
    while (true) {
    	
    	
		cout<<"\n  ------------------------------------------\n";
    	
		cout<<"  'Welcome to Godfred Registration Portal'\n";
    	cout<<"----------------------------------------------\n";
		cout<<"\n   Select an option below to proceed"<<endl;
    	
        cout << "\n\t 1. Register" << endl;
        cout << "\t 2. Login" << endl;
        cout << "\t 3. Forgot Password" << endl;
        cout << "\t 4. Exit" << endl;
        cout<<"    --------------------------\n";
        cout << "\tEnter your choice: ";
        cin >> choice;
        
        system("cls");
        
        switch (choice) {
            case 1:
                userManager.registerUser();
                break;
            case 2:
                userManager.loginUser();
                break;
            case 3:
                userManager.resetPassword();
                break;
            case 4:
                return 0;
            default:
                cout << "\n\t......Invalid choice!......" << endl;
        }
    }
}
